export interface ReduxErrorProps {
    data?: {
        message?: string;
    }
}